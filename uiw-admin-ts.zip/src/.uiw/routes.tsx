
// @ts-nocheck
import React from "react";
import {Exceptions404,Exceptions403,Exceptions500 } from "@uiw-admin/exceptions"
export default [
  {
    "path": "/login",
    "component": React.lazy(() => import('@/layouts/UserLayout'))
  },
  {
    "path": "/",
    "component": React.lazy(() => import('@/layouts/BasicLayout')),
    "routes": [
      {
        "index": true,
        "redirect": "/tableList"
      },
      {
        "path": "/tableList",
        "name": "查询表格",
        "component": React.lazy(() => import('@/pages/TableList')),
        "icon": "search",
        "navigate": "(navigate) => {navigate('/tableList',{ replace: true })}"
      },
      {
        "path": "/tableList/:id",
        "name": "查询表格2",
        "component": React.lazy(() => import('@/pages/TableList')),
        "icon": "search",
        "navigate": "(navigate) => {navigate('/tableList',{ replace: true })}"
      },
      {
        "path": "/home",
        "name": "首页",
        "component": React.lazy(() => import('@/pages/TableList')),
        "icon": "home"
      },
      {
        "path": "/dom",
        "name": "子项",
        "icon": "copy",
        "isAuth": true,
        "side": true,
        "routes": [
          {
            "index": true,
            "path": "/dom/courses",
            "name": "Dashboard",
            "isAuth": true,
            "component": React.lazy(() => import('@/pages/Dashboard'))
          },
          {
            "path": "/dom/exceptions",
            "name": "异常12",
            "icon": "warning-o",
            "side": true,
            "routes": [
              {
                "index": true,
                "path": "/dom/exceptions/403",
                "name": "403-1",
                "component": <Exceptions403 />
              },
              {
                "path": "/dom/exceptions/500",
                "name": "500-1",
                "component": <Exceptions500 />
              },
              {
                "path": "/dom/exceptions/404",
                "name": "404-1",
                "component": <Exceptions404 />
              }
            ]
          }
        ]
      },
      {
        "path": "/demo",
        "name": "列表查询/新增demo",
        "component": React.lazy(() => import('@/pages/Demo')),
        "icon": "component"
      },
      {
        "path": "/exceptions",
        "name": "异常",
        "icon": "warning-o",
        "routes": [
          {
            "path": "/exceptions/403",
            "name": "403",
            "component": <Exceptions403 />
          },
          {
            "path": "/exceptions/500",
            "name": "500",
            "component": <Exceptions500 />
          },
          {
            "path": "/exceptions/404",
            "name": "404",
            "component": <Exceptions404 />
          }
        ]
      },
      {
        "path": "/403",
        "name": "403",
        "hideInMenu": true,
        "component": <Exceptions403 />
      },
      {
        "path": "/500",
        "name": "500",
        "hideInMenu": true,
        "component": <Exceptions500 />
      },
      {
        "path": "/404",
        "name": "404",
        "hideInMenu": true,
        "component": <Exceptions404 />
      },
      {
        "path": "*",
        "name": "404",
        "component": <Exceptions404 />
      }
    ]
  }
];
