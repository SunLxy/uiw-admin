module.exports = {
  tabWidth: 2,
  bracketSameLine: true,
  arrowParens: 'always',
  singleQuote: true,
  semi: false, // 行位是否使用分号，默认为true
  bracketSpacing: true, // 对象大括号直接是否有空格，默认为true，效果：{ foo: bar }
}
